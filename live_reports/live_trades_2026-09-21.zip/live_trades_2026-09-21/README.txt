Live T30 trade pack — 13 to 21 Sep 2026 (BRT)

Contents
- live_all_closed_trades.csv     112 closed fills, 85 analysis columns
- live_all_trades_analysis.json  summaries by day, coin, trail, entry branch
- live_session_closed_trades.csv last live process (19-21 Sep)
- live_session_analysis.json
- trade_charts_15m/              one 15m candlestick PNG per trade
- entry_snapshots/               factor snapshot JSON at entry (one per trade)

Notes
- Strategy: T30, momentum E2, selector NONE
- Charts: 12 x 15m bars before entry and after exit
- XTZ trade 91d80f68 (13 Sep) is stored as +540% notional; the 15m chart does not show a 5x move
- SQLite runtime DB is not included
